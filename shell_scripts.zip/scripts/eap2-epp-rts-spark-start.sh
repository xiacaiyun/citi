#!/usr/bin/env bash
#title	:	eap2-rts-spark-start.sh
#description	:	This shell script will monitor the EAP RTS Spark Job and restart if it is not running.
#author	:	BS34500
#date	:	2017-09-12
#version	:	1.0
#updated date	:	2017-10-11
#========================================================================
export SCRIPT_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DIR_PATH="$SCRIPT_PATH/../" 
LIB_PATH="$DIR_PATH/lib"
export COUNTRY_CODE=`echo ${USER^^}|cut -c 4-5`
DATE_VAR="$(date +%m-%d-%Y)"
export LOG_DIR_PATH="$DIR_PATH/log"
export LOG_FILE="$LOG_DIR_PATH/epp-rts-spark-$DATE_VAR.log"
export LOG_OP=$LOG_DIR_PATH/epp-rts-spark_$$.log
export LOG_ERR=$LOG_DIR_PATH/epp-rts-spark_$$.err
export JOB_NAME=`echo "EPP-${COUNTRY_CODE}"`

RUNNING_MSG="EAP RTS Spark Engine is running and the yarn application id is : "
NOT_RUNNING_MSG="EAP RTS Spark Engine is not running. Restarting the same....."
MESSAGE="Checking the EAP2SparkMain Spark application..."
echo "---------------------------------------"
echo "Starting ........."
echo "Date: $DATE_VAR"
if [ -f "$LOG_FILE" ]
	then
		echo "File $LOG_FILE exist, appending logs to this file."
	else
		echo "File $LOG_FILE doesn't exist. Creating a new log file..."
		mkdir "$LOG_DIR_PATH"
fi
#Write the log details in to file
logit() {
    echo "[${USER}][`date`] - ${*}" >> "${LOG_FILE}"
};


	
echo "Performing Kerberos authentication..."
kinit -k -t /opt/Cloudera/keytabs/`whoami`.`hostname -s`.keytab `whoami`/`hostname -f`@CTIP.NAM.NSROOT.NET
NN=$(hdfs getconf -confkey dfs.nameservices)
ENV=$(echo $NN |tail -c 4)
if [[ $ENV == "dev" ]];then
	PROPERTIES="eap2-rts-spark.properties"
	environment="Development"
elif [[ $ENV == "uat" ]];then
	PROPERTIES="eap2-rts-spark_uat.properties"
	environment="UAT"
elif [[ $ENV == "rod" ]];then
	PROPERTIES="eap2-rts-spark_prod.properties"
	environment="Production"
else
	echo "environment not set. exiting script"
	exit 1
fi

#echo "Initializing Spark environment...."
echo "$MESSAGE"
sparkprocess=`yarn application -list | grep $JOB_NAME |grep $USER | awk '{print $1}'`
set "$sparkprocess"
pid=$1
if [ ! -z "$pid" -a "$pid"!=" " ] 
then
	echo "$RUNNING_MSG" $pid
	logit "$RUNNING_MSG" $pid
else
	echo "$NOT_RUNNING_MSG"
	logit "$NOT_RUNNING_MSG"
	spark-submit --name $JOB_NAME --class eap2.rts.spark.EAP2RTSSparkMain --master yarn-cluster --queue=root.gcgdmrts --driver-memory 8g --executor-memory 8g --executor-cores 2 --driver-cores 2 --driver-java-options "-XX:PermSize=256m -XX:MaxPermSize=4096m" --num-executors 5 --conf spark.eventLog.enabled=true --conf spark.ui.view.acls=* --jars ${LIB_PATH}/mongo-java-driver-3.4.2.jar,${LIB_PATH}/ojdbc6-1.0.0.jar,${LIB_PATH}/jms.jar,${LIB_PATH}/tibjms.jar,${LIB_PATH}/tibcrypt.jar,${LIB_PATH}/tibemsd_sec.jar,${LIB_PATH}/tibjmsadmin.jar,${LIB_PATH}/tibjmsapps.jar,${LIB_PATH}/tibjmsufo.jar,${LIB_PATH}/tibrvjms.jar,${LIB_PATH}/rts-common-1.0.jar,${LIB_PATH}/rts-pwp-1.0.jar --conf spark.driver.maxResultSize=4g ${DIR_PATH}/rts-spark-engine-1.0.jar $JOB_NAME $PROPERTIES 1>>$LOG_OP 2>>$LOG_ERR &
	echo  "$JOB_NAME for COUNTRY $COUNTRY_CODE has been restarted with user : $USER on server : `hostname`" | mail -r dl.gfds.aspac.big.data.operations@imcnam.ssmb.com -s "Alert: EAP RTS Job $environment: $JOB_NAME: Started" dl.gfds.aspac.big.data.operations@imcnam.ssmb.com
	nohup $SCRIPT_PATH/logrotator_daemon.sh $LOG_ERR &
fi
