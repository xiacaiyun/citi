LIB_PATH=/data/1/gcgsga/bin/apps/eap-rts/lib
DIR_PATH=/data/1/gcgsga/bin/apps/eap-rts
spark-submit --name TEST-PUB-TIBCO-UAT \
--class eap2.rts.spark.EAP2RTSSparkMain \
--master yarn-client\
--queue=root.analyst \
--driver-memory 8g \
--executor-memory 8g \
--executor-cores 5 \
--driver-cores 2 \
--driver-java-options "-XX:PermSize=256m -XX:MaxPermSize=4096m" \
--num-executors 2 \
--conf spark.eventLog.enabled=true \
--conf spark.ui.view.acls=* \
--jars ${LIB_PATH}/mongo-java-driver-3.4.2.jar,${LIB_PATH}/ojdbc6-1.0.0.jar,${LIB_PATH}/jms.jar,${LIB_PATH}/tibjms.jar,${LIB_PATH}/tibcrypt.jar,${LIB_PATH}/tibemsd_sec.jar,${LIB_PATH}/tibjmsadmin.jar,${LIB_PATH}/tibjmsapps.jar,${LIB_PATH}/tibjmsufo.jar,${LIB_PATH}/tibrvjms.jar,${LIB_PATH}/rts-common-1.0.jar,${LIB_PATH}/rts-pwp-1.0.jar \
--conf spark.driver.maxResultSize=4g \
${DIR_PATH}/rts-spark-engine-1.0.jar TEST-PUB-TIBCO-UAT eap2-rts-spark_uat.properties
