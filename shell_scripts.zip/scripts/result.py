from pyspark.sql import HiveContext
from pyspark.sql import Row
from pyspark.sql.functions import *
from pyspark import SparkContext
sc =SparkContext()
from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)
hive_context = HiveContext(sc)
import os
ASOFDT=os.environ['ASOFDT']
COUNTRY_CD=os.environ['COUNTRY_CD']
HSCHEMA=os.environ['HSCHEMA']
hive_context.sql("use {}".format(HSCHEMA))
queryin1='select string(C.grb_nbr) as clnt_nbr, string(rank),string(merchant_id) from recommendations_cosine A inner join cardslist_mre C on C.card_id=A.card_id and C.asofdt=A.asofdt where A.asofdt = "{}"'.format(ASOFDT)
df_nbt = hive_context.sql(queryin1)
ranks=sorted(df_nbt.rdd.map(lambda x: x[1]).distinct().collect())
grouped_nbt = (df_nbt.rdd.map(lambda row: (row.clnt_nbr, (row.rank, row.merchant_id))).groupByKey())
def make_row(kv):
        k , vs = kv
        tmp = dict(list(vs) + [("clnt_nbr" , k)])
        return Row(**{k: tmp.get(k , 0) for k in ["clnt_nbr"] + ranks})

reshaped2 =sqlContext.createDataFrame(grouped_nbt.map(make_row))
transposed_nbt= reshaped2.select("clnt_nbr" ,"1" ,"2" ,"3" ,"4" ,"5" ,"6" ,"7" ,"8" ,"9" ,"10" ,"11" ,"12" ,"13" ,"14" ,"15" ,"16" ,"17" ,"18" ,"19" ,"20" ,"21" ,"22" ,"23" ,"24" ,"25" ,"26" ,"27" ,"28" ,"29" ,"30" ,"31" ,"32" ,"33" ,"34" ,"35" ,"36" ,"37" ,"38" ,"39" ,"40" ,"41" ,"42" ,"43" ,"44" ,"45" ,"46" ,"47" ,"48" ,"49" ,"50" ,"51" ,"52" ,"53" ,"54" ,"55" ,"56" ,"57" ,"58" ,"59" ,"60" ,"61" ,"62" ,"63" ,"64" ,"65" ,"66" ,"67" ,"68" ,"69" ,"70" ,"71" ,"72" ,"73" ,"74" ,"75" ,"76" ,"77" ,"78" ,"79" ,"80" ,"81" ,"82" ,"83" ,"84" ,"85" ,"86" ,"87" ,"88" ,"89" ,"90" ,"91" ,"92" ,"93" ,"94" ,"95" ,"96" ,"97" ,"98" ,"99" ,"100" ,"101" ,"102" ,"103" ,"104" ,"105" ,"106" ,"107" ,"108" ,"109" ,"110" ,"111" ,"112" ,"113" ,"114" ,"115" ,"116" ,"117" ,"118" ,"119" ,"120" ,"121" ,"122" ,"123" ,"124" ,"125" ,"126" ,"127" ,"128" ,"129" ,"130" ,"131" ,"132" ,"133" ,"134" ,"135" ,"136" ,"137" ,"138" ,"139" ,"140" ,"141" ,"142" ,"143" ,"144" ,"145" ,"146" ,"147" ,"148" ,"149" ,"150" ,"151" ,"152" ,"153" ,"154" ,"155" ,"156" ,"157" ,"158" ,"159" ,"160" ,"161" ,"162" ,"163" ,"164" ,"165" ,"166" ,"167" ,"168" ,"169" ,"170" ,"171" ,"172" ,"173" ,"174" ,"175" ,"176" ,"177" ,"178" ,"179" ,"180" ,"181" ,"182" ,"183" ,"184" ,"185" ,"186" ,"187" ,"188" ,"189" ,"190" ,"191" ,"192" ,"193" ,"194" ,"195" ,"196" ,"197" ,"198" ,"199" ,"200")
transposed_nbt.createOrReplaceTempView("transposed_nbt")
hive_context.setConf("hive.exec.dynamic.partition", "true")
hive_context.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
queryout1='INSERT OVERWRITE TABLE recommendations_cosine_tx PARTITION(mis_dt) select A.*,"{}" as country_code,"{}" as mis_dt from transposed_nbt A'.format((COUNTRY_CD), (ASOFDT))
sqlContext.sql(queryout1)
queryin2='select string(C.grb_nbr) as clnt_nbr, rank,string(merch_id) from recommendations_disengaged A inner join cardslist_mre C on C.card_id=A.card_id and C.asofdt=A.asofdt where A.asofdt = "{}"'.format(ASOFDT)
df_disenagaged = hive_context.sql(queryin2)
grouped_disengaged = (df_disenagaged.rdd.map(lambda row: (row.clnt_nbr, (row.rank, row.merch_id))).groupByKey())
def rank_merchs(kv):
	k, vs = kv
	vs = sorted(vs)
	ranked_merchants = [k]
	for i in vs :
		ranked_merchants.append(i[1])
	for i in range(len(ranked_merchants), 201):
		ranked_merchants.append("")
	return ranked_merchants

transposed_disengaged= sqlContext.createDataFrame(grouped_disengaged.map(rank_merchs),["client_nbr", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200"])
transposed_disengaged.createOrReplaceTempView("transposed_disengaged")
queryout2='INSERT OVERWRITE TABLE recommendations_disengaged_tx PARTITION(mis_dt) select A.*,"{}" as country_code,"{}" as mis_dt from transposed_disengaged A'.format((COUNTRY_CD), (ASOFDT))
sqlContext.sql(queryout2)
queryin3='select string(C.grb_nbr) as clnt_nbr, rank,string(merch_id) from recommendations_beenthere A inner join cardslist_mre C on C.card_id=A.card_id and C.asofdt=A.asofdt where A.asofdt = "{}"'.format(ASOFDT)
df_engaged = hive_context.sql(queryin3)
grouped_engaged = (df_engaged.rdd.map(lambda row: (row.clnt_nbr, (row.rank, row.merch_id))).groupByKey())
transposed_engaged= sqlContext.createDataFrame(grouped_engaged.map(rank_merchs),["client_nbr", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200"])
transposed_engaged.createOrReplaceTempView("transposed_engaged")
queryout2='INSERT OVERWRITE TABLE recommendations_engaged_tx PARTITION(mis_dt) select A.*,"{}" as country_code,"{}" as mis_dt from transposed_engaged A'.format((COUNTRY_CD), (ASOFDT))
sqlContext.sql(queryout2)


